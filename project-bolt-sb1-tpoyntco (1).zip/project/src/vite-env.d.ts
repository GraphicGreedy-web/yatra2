/// <reference types="vite/client" />
const spreedspreedid = process.env.REACT_APP_GOOGLE_SHEETS_1CQFcfAuDmb_Bwe2uDpzD_vG81SA9x0sNtuQo7pIwzBQ;